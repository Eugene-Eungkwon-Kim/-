
# AVM 프로젝트 - 한국 부동산 데이터 수집 완전 가이드

## 1. Data.go.kr API 설정

### 1.1 회원가입 및 API 키 발급

**단계별 절차:**

1. **웹사이트 접속**
   - URL: https://www.data.go.kr/

2. **회원가입**
   - 일반/기관 회원가입 선택
   - 이메일, 비밀번호, 기본 정보 입력
   - 이메일 인증 완료

3. **데이터셋 검색 및 활용신청**
   - 검색창에서 "부동산" 검색
   - 원하는 데이터셋 클릭
   - "활용신청" 버튼 클릭
   - 활용 목적 입력 후 신청

4. **API 키 확인**
   - 마이페이지 > "나의 API 이용 현황" 접속
   - 승인된 데이터셋 확인
   - "API 키" 버튼 클릭하여 키 복사

5. **개발계정 등록**
   - "개발계정 관리" 메뉴 접속
   - API 키를 개발계정에 등록
   - 인증키 확인 및 저장

### 1.2 API 호출 테스트

**Python 예제:**

```python
import requests

api_key = 'YOUR_API_KEY'
url = 'https://apis.data.go.kr/6440000/budongsanservice/searchAPT'

params = {
    'serviceKey': api_key,
    'DEAL_YMD': '202406',
    'numOfRows': 10,
    '_returnType': 'json'
}

response = requests.get(url, params=params)
print(response.json())
```

## 2. 주요 데이터셋 상세 정보

### 2.1 부동산 실거래 정보

**API 엔드포인트:**
```
https://apis.data.go.kr/6440000/budongsanservice/searchAPT
```

**필수 파라미터:**
- serviceKey (API 키)
- DEAL_YMD (거래월: YYYYMM)

**선택 파라미터:**
- REGION_CODE (지역코드)
- numOfRows (한 페이지 건수, 기본값: 10, 최대: 100)
- pageNo (페이지 번호, 기본값: 1)

**응답 필드:**
- 거래일자, 지역명, 거래가격
- 도로명주소, 아파트명, 층
- 건물면적, 토지면적, 건축년도

**활용 팁:**
- 월별로 데이터 수집 (API 트래픽 관리)
- 지역코드로 특정 지역만 수집 가능
- 100건 단위로 페이징 처리

### 2.2 공시지가 정보

**API 엔드포인트:**
```
https://apis.data.go.kr/1611000/nsdi/IndvdLandPriceService/getLandPriceInfo
```

**필수 파라미터:**
- serviceKey (API 키)
- stdrYear (기준년도)

**응답 필드:**
- 공시년도, 시도, 시군구
- 지번, 지목, 공시지가
- 지가변동률, 면적, 용도지역

**주의사항:**
- 연 1회 공시 (7월경)
- 대량 데이터이므로 페이징 필수
- 메모리 관리에 주의

## 3. 한국부동산원 데이터 수집

### 3.1 웹 스크래핑

**주요 페이지:**
- 주간 아파트 동향: https://www.kab.co.kr/stat/statView.do?menukey=60&statkey=60131
- 아파트 가격지수: https://www.kab.co.kr/stat/statView.do?menukey=60&statkey=60109
- 오피스 시장: https://www.kab.co.kr/stat/statView.do?menukey=60&statkey=60202

**Python BeautifulSoup 예제:**

```python
import requests
from bs4 import BeautifulSoup
import pandas as pd

url = 'https://www.kab.co.kr/stat/statView.do?menukey=60&statkey=60109'
response = requests.get(url)
soup = BeautifulSoup(response.content, 'html.parser')

# 테이블 파싱
table = soup.find('table')
df = pd.read_html(str(table))[0]

# CSV로 저장
df.to_csv('apartment_price_index.csv', index=False, encoding='utf-8')
```

### 3.2 엑셀 파일 다운로드

**수동 다운로드 프로세스:**

1. 한국부동산원 사이트 접속
2. 원하는 통계 페이지 이동
3. "다운로드" 또는 "엑셀" 버튼 클릭
4. 파일 저장
5. Python으로 읽기

```python
import pandas as pd

# 엑셀 파일 읽기
df = pd.read_excel('apartment_price_index.xlsx')

# CSV로 변환
df.to_csv('apartment_price_index.csv', index=False, encoding='utf-8')
```

## 4. 데이터 통합 및 정제

### 4.1 데이터 병합

```python
import pandas as pd
from glob import glob

# 모든 CSV 파일 로드
csv_files = glob('avm_project/data/raw/*.csv')
dfs = [pd.read_csv(f) for f in csv_files]

# 데이터 병합
combined_df = pd.concat(dfs, ignore_index=True)

# 저장
combined_df.to_csv('avm_project/data/raw/combined_real_estate_data.csv',
                    index=False, encoding='utf-8')
```

### 4.2 데이터 정제

```python
# 결측값 처리
combined_df.fillna(combined_df.mean(), inplace=True)

# 중복값 제거
combined_df.drop_duplicates(inplace=True)

# 데이터 타입 변환
combined_df['거래가격'] = pd.to_numeric(combined_df['거래가격'], errors='coerce')
combined_df['거래일자'] = pd.to_datetime(combined_df['거래일자'], format='%Y%m%d')

# 저장
combined_df.to_csv('avm_project/data/raw/cleaned_real_estate_data.csv',
                    index=False, encoding='utf-8')
```

## 5. 데이터 저장 및 관리

### 5.1 디렉토리 구조

```
avm_project/data/
├── raw/                          # 원본 데이터
│   ├── real_estate_transaction_*.csv
│   ├── jeonse_data_*.csv
│   ├── land_price_*.csv
│   ├── combined_real_estate_data.csv
│   └── cleaned_real_estate_data.csv
├── processed/                     # 전처리된 데이터
│   └── (전처리 결과)
└── metadata.json                  # 데이터 메타정보
```

### 5.2 메타데이터 기록

```json
{
  "data_collection_date": "2026-06-09",
  "sources": [
    {
      "name": "부동산 실거래 정보",
      "period": "202401-202406",
      "records": 50000,
      "columns": ["거래일자", "지역명", "거래가격", ...]
    },
    {
      "name": "공시지가",
      "year": 2024,
      "records": 100000,
      "columns": ["공시년도", "시도", "공시지가", ...]
    }
  ],
  "total_records": 150000,
  "total_size_mb": 45.5
}
```

## 6. API 호출 제한 및 효율성

### 6.1 Rate Limiting

```python
import time
from requests.adapters import HTTPAdapter
from requests.packages.urllib3.util.retry import Retry

def create_session_with_retries():
    session = requests.Session()
    retry = Retry(
        total=3,
        backoff_factor=0.5,
        status_forcelist=[429, 500, 502, 503, 504]
    )
    adapter = HTTPAdapter(max_retries=retry)
    session.mount('http://', adapter)
    session.mount('https://', adapter)
    return session

# 사용
session = create_session_with_retries()
response = session.get(url, params=params)
```

### 6.2 배치 처리

```python
import time
from datetime import datetime, timedelta

# 월별 데이터 수집
current_month = datetime(2024, 1, 1)
end_month = datetime(2024, 6, 30)

while current_month <= end_month:
    month_str = current_month.strftime('%Y%m')
    print(f"수집: {month_str}")

    # API 호출
    # ...

    # 다음 달로 이동
    current_month += timedelta(days=32)
    current_month = current_month.replace(day=1)

    # 요청 제한 준수
    time.sleep(1)
```

## 7. 문제 해결

### 7.1 API 호출 오류

| 오류 | 원인 | 해결책 |
|------|------|--------|
| 400 Bad Request | 파라미터 오류 | 파라미터 형식 확인 |
| 401 Unauthorized | API 키 오류 | API 키 재확인 |
| 429 Too Many Requests | 호출 제한 초과 | 요청 간격 증가 |
| 503 Service Unavailable | 서버 오류 | 일시간 후 재시도 |

### 7.2 데이터 품질 문제

```python
# 데이터 검증
def validate_data(df):
    issues = []

    # 필수 컬럼 확인
    required_cols = ['거래일자', '거래가격', '지역명']
    if not all(col in df.columns for col in required_cols):
        issues.append("필수 컬럼 누락")

    # 데이터 타입 확인
    if df['거래가격'].dtype != 'float64':
        issues.append("거래가격 데이터 타입 오류")

    # 범위 확인
    if (df['거래가격'] < 0).any():
        issues.append("음수 거래가격 발견")

    return issues

# 검증 실행
issues = validate_data(df)
if issues:
    print(f"데이터 문제: {issues}")
```

## 8. 다음 단계

1. **자동화 스크립트 개발**
   - 정기적 데이터 수집 (Cron Job 사용)
   - 자동 정제 및 검증

2. **데이터베이스 구축**
   - PostgreSQL 또는 MongoDB에 저장
   - 색인 생성으로 쿼리 최적화

3. **데이터 통합**
   - 여러 소스의 데이터 통합
   - 공통 키(지번, 주소 등)로 조인

4. **AVM 모델 학습**
   - 전처리된 데이터로 모델 훈련
   - 성능 평가 및 개선

---

**작성일:** 2026-06-09
**최종 업데이트:** 2026-06-09
